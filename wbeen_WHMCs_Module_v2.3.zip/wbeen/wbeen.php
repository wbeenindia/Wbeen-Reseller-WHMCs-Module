<?php

use WHMCS\Database\Capsule;
use WHMCS\Module\Registrar\Wbeen\Request;
use WHMCS\Domain\TopLevel\ImportItem;
use WHMCS\Results\ResultsList;

function wbeen_MetaData()
{
    return array(
        'DisplayName' => 'WBeen',
        'APIVersion' => '1.0',
    );
}

function wbeen_GetConfigArray()
{
    return array(
        "Description" => array("Type" => "System", "Value" => "Don't have a Wbeen Account yet? Get one here: " . "<a href=\"https://www.wbeen.com/manage/register.php\" target=\"_blank\">" . "https://www.wbeen.com/</a>"),
        "email" => array("FriendlyName" => "Email Address:", "Type" => "text", "Size" => "25", "Default" => "", "Description" => "Enter your email address which you registered in our system."),        		
        "apikey" => array("FriendlyName" => "API Key:", "Type" => "text", "Size" => "25", "Default" => "", "Description" => "Enter your API Key."),
    );
}

function wbeen_RegisterDomain($params)
{
    $params_to_send = [
        'firstname' => '',
        'lastname' => '',
        'companyname' => '',
        'address1' => '',
        'address2' => '',
        'city' => '',
        'state' => '',
        'postcode' => '',
        'country' => '',
        'fullphonenumber' => '',
        'ns1' => '',
        'ns2' => '',
        'ns3' => '',
        'ns4' => '',
        'ns5' => '',
        'email' => '',
        'domain' => '',
        'regperiod' => '',
    ];
    foreach ($params_to_send as $key => $value) {
        if (isset($params[$key])) {
            $params_to_send[$key] = $params[$key];
        }
    }
    $params_to_send['phonenumber'] = $params_to_send['fullphonenumber'];
    $params_to_send['action'] = 'register';
    $result = Request::call($params_to_send);
    if ($result['result'] == 'success') {
        return array("success" => "complete");
    } else {
        return array("error" => $result['data']);
    }
}

function wbeen_TransferDomain($params)
{
    $params_to_send = [
        'firstname' => '',
        'lastname' => '',
        'companyname' => '',
        'address1' => '',
        'address2' => '',
        'city' => '',
        'state' => '',
        'postcode' => '',
        'country' => '',
        'fullphonenumber' => '',
        'ns1' => '',
        'ns2' => '',
        'ns3' => '',
        'ns4' => '',
        'ns5' => '',
        'email' => '',
        'domain' => '',
        'eppcode' => '',
        'regperiod' => '',
        'transfersecret' => '',
    ];
    foreach ($params_to_send as $key => $value) {
        if (isset($params[$key])) {
            $params_to_send[$key] = $params[$key];
        }
    }
    $params_to_send['eppcode'] = $params_to_send['transfersecret'];
    $params_to_send['phonenumber'] = $params_to_send['fullphonenumber'];
    $params_to_send['action'] = 'transfer';
    $result = Request::call($params_to_send);
    if ($result['result'] == 'success') {
        return array("success" => "complete");
    } else {
        return array("error" => $result['data']);
    }

}

function wbeen_RenewDomain($params)
{
    $params_to_send['regperiod'] = $params['regperiod'];
    $params_to_send['domain'] = $params['domain'];
    $params_to_send['action'] = 'renew';
    $result = Request::call($params_to_send);
    if ($result['result'] == 'success') {
        return array("success" => "complete");
    } else {
        return array("error" => $result['data']);
    }
}

function wbeen_GetNameservers($params)
{
    $params_to_send = [];
    $params_to_send['domain'] = $params['domain'];
    $params_to_send['action'] = 'getNameServers';
    $result = Request::call($params_to_send);
    return $result['data'];
}

function wbeen_SaveNameservers($params)
{

    $postfields = [];
    $postfields['action'] = 'updateNameServers';
    $postfields['domain'] = $params['domain'];
    if ($params['ns1']) {
        $postfields["ns1"] = $params['ns1'];
    }
    if ($params['ns2']) {
        $postfields["ns2"] = $params['ns2'];
    }
    if ($params['ns3']) {
        $postfields["ns3"] = $params['ns3'];
    }
    if ($params['ns4']) {
        $postfields["ns4"] = $params['ns4'];
    }
    if ($params['ns5']) {
        $postfields["ns5"] = $params['ns5'];
    }
    $response = Request::call($postfields);
    if ($response['result'] != 'success') {
        return array('error' => $response['data']);
    }
}


function wbeen_GetRegistrarLock($params)
{

    $postfields['domain'] = $params['domain'];
    $postfields['action'] = 'lockStatus';
    $lock_status = Request::call($postfields);
    if ($lock_status['result'] == 'success') {
        return $lock_status['data'];
    } else {
        return ['error' => $lock_status['data']];
    }
}

function wbeen_SaveRegistrarLock($params)
{
    $postfields['domain'] = $params['domain'];
    $postfields['action'] = 'updateLock';
    $postfields['lock'] = $params['lockenabled'] == "locked" ? 1 : 0;
    $lock_status = Request::call($postfields);
    if ($lock_status['result'] == 'success') {
        return $lock_status['data'];
    } else {
        return ['error' => $lock_status['data']];
    }
}

function wbeen_GetEPPCode($params)
{

    $postfields['domain'] = $params['domain'];
    $postfields['action'] = 'getEPP';
    $epp_status = Request::call($postfields);
    if ($epp_status['result'] == 'success') {
        return array('eppcode' => $epp_status['data']);
    } else {
        return ['error' => $epp_status['data']];
    }

}


function wbeen_GetContactDetails($params)
{

    $postfields['domain'] = $params['domain'];
    $postfields['action'] = 'getContactDetails';
    $lock_status = Request::call($postfields);
    unset($lock_status['data']['result']);
    if ($lock_status['result'] == 'success') {
        return $lock_status['data'];
    } else {
        return ['error' => $lock_status['data']];
    }
}


function wbeen_SaveContactDetails($params)
{
    $postfields['domain'] = $params['domain'];
    $postfields['contactdetails'] = json_encode($params['contactdetails']);
    $postfields['action'] = 'saveContactDetails';
    $lock_status = Request::call($postfields);
    if ($lock_status['result'] != 'success') {
        return ['error' => $lock_status['data']];
    }

}

// Pricing test--------------->


// function wbeen_GetTldPricing(array $params)
// {
//     $params_to_send = [];
//     $params_to_send['action'] = 'GetTldPricing';
//     $result = Request::call($params_to_send);
//     if ($result['result'] == 'success') {
        
//         $results = new ResultsList;
//         $currency = $result["data"]["currency"]["code"];
//         foreach ($result["data"]["pricing"] as $extension => $value) {
//             // All the set methods can be chained and utilised together.
//             $item = (new ImportItem)
//                 ->setExtension($extension)
//                 ->setMinYears(1)
//                 ->setMaxYears(1)
//                 ->setRegisterPrice($value["register"][1])
//                 ->setRenewPrice($value["renew"][1])
//                 ->setTransferPrice($value["transfer"][1])
//                 ->setCurrency($currency)
//                 ->setEppRequired($value['transferSecretRequired']);
    
//             $results[] = $item;
//         }
//         return $results;
//         // return array("error" => json_encode($result["data"]["pricing"]["in"]));
//     } else {
//          return array("error" => $result["data"]["pricing"]);
//     } 
// }
// NEW TLD Pricing Sync--------------->

function wbeen_GetTldPricing(array $params)
{
    $params_to_send = [];
    $params_to_send['action'] = 'GetTldPricing';
    $result = Request::call($params_to_send);
    if ($result['result'] == 'success') {
        
        $results = new ResultsList;
        $currency = $result["data"]["currency"]["code"];
        $exchangeRate = 1; // Default exchange rate (1:1 for USD)
        
        // Check if the currency is INR and convert to USD if necessary
        if ($currency == 'INR') {
            $exchangeRate = getExchangeRate('INR', 'USD');
        }
        
        foreach ($result["data"]["pricing"] as $extension => $value) {
            // Convert prices to USD if the original currency is INR
            $registerPriceUSD = $value["register"][1] * $exchangeRate;
            $renewPriceUSD = $value["renew"][1] * $exchangeRate;
            $transferPriceUSD = $value["transfer"][1] * $exchangeRate;

            // All the set methods can be chained and utilised together.
            $item = (new ImportItem)
                ->setExtension($extension)
                ->setMinYears(1)
                ->setMaxYears(1)
                ->setRegisterPrice($registerPriceUSD)
                ->setRenewPrice($renewPriceUSD)
                ->setTransferPrice($transferPriceUSD)
                ->setCurrency('USD') // Set to USD after conversion
                ->setEppRequired($value['transferSecretRequired']);

            $results[] = $item;
        }
        return $results;
    } else {
         return array("error" => $result["data"]["pricing"]);
    } 
}

function getExchangeRate($from, $to) {
    // Implement the logic to get the current exchange rate
    // This can be an API call to a service like exchangeratesapi.io, openexchangerates.org, etc.
    // Example:
    // $response = file_get_contents("https://api.exchangerate-api.com/v4/latest/$from");
    // $data = json_decode($response, true);
    // return $data['rates'][$to];

    // For simplicity, let's assume the exchange rate is hardcoded for now
    // You should replace this with actual API call logic
    return 0.013; // Example: 1 INR = 0.013 USD
}

