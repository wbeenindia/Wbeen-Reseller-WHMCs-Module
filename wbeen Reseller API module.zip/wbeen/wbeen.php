<?php
use WHMCS\Module\Registrar\wbeen\Apiclient;
use WHMCS\Database\Capsule;

    function wbeen_MetaData() {
        return array(
            'DisplayName' => 'Wbeen ClientArea Domain Module for WHMCS',
            'APIVersion' => '1.0',
        );
    }
    function wbeen_GetConfigArray()
    {
        return array(
            "Description" => array("Type" => "System","Value" => "Don't have a Wbeen Account yet? Get one here: " . "<a href=\"https://www.wbeen.com/manage/register.php\" target=\"_blank\">" . "https://www.wbeen.com/</a>"),
            "client-email"=> array("FriendlyName" => "Email:","Type" => "text","Size" => "25","Default" => "", "Description" => "Enter your Email Id."),
            "client-pass"       => array("FriendlyName" => "Password:","Type" => "password","Size" => "25","Default" => "", "Description" => "Enter your Wbeen Account Password.")
            );
    }
    
function wbeen_RegisterDomain($params)
{
    
         // submitted nameserver values
        $nameserver1 = $params['ns1'];
        $nameserver2 = $params['ns2'];
        $nameserver3 = $params['ns3'];
        $nameserver4 = $params['ns4'];
        $nameserver5 = $params['ns5'];
        
        if ($nameserver1) {
            $postfields['nameserver1'] = $params['ns1'];
        }
        if ($nameserver2) {
            $postfields['nameserver2'] = $params['ns2'];
        }
        if ($nameserver3) {
            $postfields['nameserver3'] = $params['ns3'];
        }
        if ($nameserver4) {
            $postfields['nameserver4'] = $params['ns4'];
        }
        if ($nameserver5) {
            $postfields['nameserver5'] = $params['ns5'];
        }     
        
        $postfields['domain']      =   $params['domainname'];
        $postfields['regperiod']   =   $params['regperiod'];
        
        
        $response = Apiclient::call('domain/register','GET', $postfields);
    
        if(!$response['success']){
            
            return  array('error' =>  Apiclient::error($response['errors']));
        }
    
}

function wbeen_TransferDomain($params)
{
    
    if(!empty($params['transfersecret'])){
        
        $postfields['domain']   =   $params['domainname'];
        $postfields['eppcode']  =   $params['transfersecret'];
        
        
        $response = Apiclient::call('domain/transfer','GET', $postfields);
    
        if(!$response['success']){
            
            return  array('error' =>  Apiclient::error($response['errors']));
        }           
        
    }else{
        return  array('error' =>  'EPP Code Can\'t Blank');
    }

    
}
function wbeen_GetNameservers($params)
    {
        $domain = Apiclient::getDomain($params['domainid']);
        
        if($domain->status == 'Active') {
            
            $postfields['domainname'] = $params['domainname'];
            
             $response = Apiclient::call('domain/view/nameserver','POST', $postfields);
            
             if($response['success']){
                
                 $return = array();
                $x=0;
                foreach($response['nameservers'] as $key){
                    $x++;
                    $ns="ns".$x;
                    $return["ns".$x]   = $key;
                }   
                
            return $return;
                 
            }else{
                  return  array('error' =>  Apiclient::error($response['errors']));
            }
        }else{
            
            // domain Not Active Whmcs Softwere
            return array('error' => 'Domain is not Active.');
        }
    } 
    
    function wbeen_SaveNameservers($params) {
        $domain = Apiclient::getDomain($params['domainid']);
        
        if($domain->status == 'Active') {
            
            $postfields['domainname'] = $params['domainname'];
            
            // submitted nameserver values
            $nameserver1 = $params['ns1'];
            $nameserver2 = $params['ns2'];
            $nameserver3 = $params['ns3'];
            $nameserver4 = $params['ns4'];
            $nameserver5 = $params['ns5'];
            
            if ($nameserver1) {
                $postfields['nameserver']["ns1"] = $nameserver1;
            }
            if ($nameserver2) {
                $postfields['nameserver']["ns2"] = $nameserver2;
            }
            if ($nameserver3) {
                $postfields['nameserver']["ns3"] = $nameserver3;
            }
            if ($nameserver4) {
                $postfields['nameserver']["ns4"] = $nameserver4;
            }
            if ($nameserver5) {
                $postfields['nameserver']["ns5"] = $nameserver5;
            }                
             $response = Apiclient::call('domain/update/nameserver','POST', $postfields);
        
              if(!$response['success']){
                    
                    return  array('error' =>  Apiclient::error($response['errors']));
                     
                }
        }else{
            
            // domain Not Active Whmcs Softwere
            return array('error' => 'Domain is not Active.');
        }
    } 
    
    
    function wbeen_GetRegistrarLock($params) {
        $domain = Apiclient::getDomain($params['domainid']);
        
        if($domain->status == 'Active') {
            
            $postfields['domainname'] = $params['domainname'];
            
             $response = Apiclient::call('domain/view/TheftProtection','GET', $postfields);
            
             if($response['success']){
                 
                 if($response['isThiefProtected']) {
                     
                     return 'locked';
                 }
             }else{
                return  array('error' =>  Apiclient::error($response['errors']));
            }
        }else{
            
            // domain Not Active Whmcs Softwere
            return array('error' => 'Domain is not Active.');
        }
    }
    
    function wbeen_SaveRegistrarLock($params) {
        $domain = Apiclient::getDomain($params['domainid']);
        
        if($domain->status == 'Active') {
            
            $postfields['domainname'] = $params['domainname'];
            $postfields['isThiefProtected'] = "false";
            
            if($params['lockenabled'] == "locked") {
                
                $postfields['isThiefProtected'] = "true";
                
            }
             $response = Apiclient::call('domain/update/TheftProtection','POST', $postfields);
            
              if(!$response['success']){
                    
                    return  array('error' =>  Apiclient::error($response['errors']));
                     
                }
        }else{
            
            // domain Not Active Whmcs Softwere
            return array('error' => 'Domain is not Active.');
        }
    }
    
    function wbeen_GetEPPCode($params) {
        $domain = Apiclient::getDomain($params['domainid']);
        
        if($domain->status == 'Active') {
            
            $postfields['domainname'] = $params['domainname'];
            
              $response = Apiclient::call('domain/view/TransferCode','GET', $postfields);
                    
              if($response['success']){
                    
                    return array('eppcode' =>  $response['TransferCode']);
                     
                }else{
                     return  array('error' =>  Apiclient::error($response['errors']));
                }
        }else{
            
            // domain Not Active Whmcs Softwere
            return array('error' => 'Domain is not Active.');
        }
    }    