<?php
namespace WHMCS\Module\Registrar\wbeen;
use WHMCS\Database\Capsule;
class Apiclient {
    
    const API_URL = 'https://api.myapi.co.in/whmcs/wbeen/';
    
    public static function call($action, $callmethod, $postfields){
        
        $client_pass    =  decrypt(Apiclient::getauth('client-pass')->value, $cc_encryption_hash);
        $client_email =  decrypt(Apiclient::getauth('client-email')->value, $cc_encryption_hash);
        
        
        $return = array(
            'success'   =>  FALSE,
            'errors'    =>  array(),
            'messages'  =>  array(),
            'result'    =>  array()
            );
            
        $session = curl_init();
        curl_setopt($session, CURLOPT_URL, self::API_URL . $action . '.php');
        curl_setopt($session, CURLOPT_CUSTOMREQUEST, $callmethod);
        curl_setopt($session, CURLOPT_POSTFIELDS, json_encode($postfields));
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($session, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($session, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($session, CURLOPT_TIMEOUT, 100);
        curl_setopt($session, CURLOPT_HTTPHEADER, array(
            
            'X-Auth-Key: '. $client_pass .'',
            'X-Auth-email: '. $client_email .''
            
            )); 
            
        $response = curl_exec($session);
        
        if (curl_errno($session)) {
            $return['errors'][] =   array('message' => 'curl error: ' . curl_errno($session) . " - " . curl_error($session));
        }    
        
        curl_close($session);
        
        $results = json_decode($response, true);
        
        if ($results === null && json_last_error() !== JSON_ERROR_NONE) {
            $return['errors'][] =   array('message' => 'Bad response received from API');
        }else{
            $return = $results;
        }
        
        return $return;            
            
    }

    public static function getauth($setting) {
        return Capsule::table('tblregistrars')
                        ->where('registrar', '=', 'wbeen')
                        ->where('setting', '=', $setting)
                        ->select('value')
                        ->first();
    }
    
    public static function getDomain($domainid) {
        return Capsule::table('tbldomains')
                        ->where('id', '=', $domainid)
                        ->first();
    }

    public static function error($error){
        $x;
        $return = array();
        foreach ($error as $key => $value){
            
            $return[] = $value['message'];
          $x++;  
        }
        return $x. " Message ==> ( " . implode(", ", $return) ." )";
    }
}