<?php
if (!defined("WHMCS")) die("This file cannot be accessed directly");
use WHMCS\Module\Registrar\Wbeen\Request;
use Illuminate\Database\Capsule\Manager as Capsule;
use WHMCS\View\Menu\Item as MenuItem;

// ----------- Sidebar Enhancement: EPP Only -----------

function wbeen_sidebar(MenuItem $primarySidebar)
{
    $currentUser = new \WHMCS\Authentication\CurrentUser;
    $user = $currentUser->client();
    if (!$user) return;

    $domainDetails = $primarySidebar->getChild('Domain Details Management');
    if ($domainDetails) {
        // Only EPP code option
        $domainDetails->addChild('Get EPP Code', [
            'label' => 'Get EPP Code',
            'uri' => 'clientarea.php?action=domaingetepp&id=' . intval($_REQUEST['id']),
            'order' => 100
        ]);
        // Privacy Protection toggle (NOT needed, so lines removed)
    }
}
add_hook('ClientAreaPrimarySidebar', 1, "wbeen_sidebar");

// ----------- Admin Home Widget: Credits + Connectivity (UI Enhanced) -----------

add_hook('AdminHomeWidgets', 1, function () {
    return new WbeenAdminWidget();
});

class WbeenAdminWidget extends \WHMCS\Module\AbstractWidget
{
    protected $title = 'WBeen Reseller Status';
    protected $description = 'Your live credits & connection health';
    protected $weight = 90;
    protected $columns = 1;
    protected $cache = false;

    public function getData()
    {
        $creditResp = Request::call(['action' => 'credit']);
        $pingResp = Request::call(['action' => 'ping']);
        return [
            'credit' => $creditResp['data'] ?? $creditResp['balance'] ?? 'N/A',
            'connectivity' => (isset($pingResp['result']) && $pingResp['result'] === 'success') ? 'Connected' : 'Disconnected',
        ];
    }

    public function generateOutput($data)
    {
        $connect = ($data['connectivity'] === 'Connected')
            ? "<span style='color:#48a84d;font-weight:bold;'><svg style='height:13px;vertical-align:middle;margin-right:3px;' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'><circle cx='8' cy='8' r='7' fill='#28a745'/></svg>Connected</span>"
            : "<span style='color:red;font-weight:bold;'><svg style='height:13px;vertical-align:middle;margin-right:3px;' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'><circle cx='8' cy='8' r='7' fill='#dc3545'/></svg>Disconnected</span>";

        return <<<HTML
<div style="padding:16px 8px 12px 8px;font-size:15px;line-height:1.7;min-width:180px;">
    <div style="margin-bottom:10px;">
        <span style="font-weight:500;">WBeen Credits:</span>
        <span style="font-size:1.12em;color:#48a84d;font-weight:bold;">{$data['credit']}</span>
    </div>
    <div>
        <span style="font-weight:500;">API Connection:</span>
        {$connect}
    </div>
</div>
HTML;
    }
}


// ----------- Cron Hook: Auto Domain Status/Expiry Sync (Unchanged) -----------

add_hook('AfterCronJob', 1, function ($vars) {
    $last_check = \WHMCS\Config\Setting::getValue('wbeen_domains_last_sync');
    $logAction = 'wbeen_domain_sync_cron';

    if (
        !$last_check
        || (\Carbon\Carbon::parse($last_check)->addMinutes(30)->toDateTimeString() <= \Carbon\Carbon::now()->toDateTimeString())
    ) {
        $data = Request::call(['action' => 'domains']);
        if (isset($data['result']) && $data['result'] === 'success' && !empty($data['data'])) {
            foreach ($data['data'] as $domain) {
                try {
                    Capsule::table('tbldomains')
                        ->whereRaw("LOWER(registrar) = 'wbeen'")
                        ->where('domain', $domain['domain'])
                        ->update(['status' => $domain['status']]);
                    Capsule::table('tbldomains')
                        ->whereRaw("LOWER(registrar) = 'wbeen'")
                        ->where('domain', $domain['domain'])
                        ->update(['expirydate' => $domain['expirydate']]);
                } catch (\Exception $e) {
                    logModuleCall('wbeen', $logAction, $domain, '', $e->getMessage(), []);
                }
            }
            logModuleCall('wbeen', $logAction, [], $data, 'success', []);
        } else {
            logModuleCall('wbeen', $logAction, [], $data, 'API Error or No Domains', []);
        }
        \WHMCS\Config\Setting::setValue('wbeen_domains_last_sync', \Carbon\Carbon::now()->toDateTimeString());
    }
});

