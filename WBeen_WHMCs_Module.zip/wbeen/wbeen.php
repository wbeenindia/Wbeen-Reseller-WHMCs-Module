<?php

use WHMCS\Database\Capsule;
use WHMCS\Module\Registrar\Wbeen\Request;
use WHMCS\Domain\TopLevel\ImportItem;
use WHMCS\Results\ResultsList;

function wbeen_MetaData()
{
    return [
        'DisplayName' => 'WBeen',
        'APIVersion'  => '2.1',
    ];
}

function wbeen_GetConfigArray()
{
    return [
        "Description" => [
            "Type" => "System",
            "Value" => "Don't have a Wbeen Account yet? <a href=\"https://www.wbeen.com/manage/register.php\" target=\"_blank\">Register here</a>",
        ],
        "email" => [
            "FriendlyName" => "Email Address:",
            "Type" => "text",
            "Size" => "25",
            "Default" => "",
            "Description" => "Enter your WBeen account email.",
        ],
        "apikey" => [
            "FriendlyName" => "API Key:",
            "Type" => "password",
            "Size" => "25",
            "Default" => "",
            "Description" => "Enter your API Key.",
        ],
    ];
}

// --------- DOMAIN ACTIONS ----------

function wbeen_RegisterDomain($params)
{
    $params_to_send = [];
    $fields = ['firstname','lastname','companyname','address1','address2','city','state','postcode','country','fullphonenumber','ns1','ns2','ns3','ns4','ns5','email','domain','regperiod'];
    foreach ($fields as $field) {
        $params_to_send[$field] = $params[$field] ?? '';
    }
    $params_to_send['phonenumber'] = $params_to_send['fullphonenumber'];
    $params_to_send['action'] = 'register';
    $result = Request::call($params_to_send);
    return ($result['result'] == 'success')
        ? ["success" => "complete"]
        : ["error" => $result['data'] ?? $result['message'] ?? 'Unknown API error'];
}

function wbeen_TransferDomain($params)
{
    $params_to_send = [];
    $fields = ['firstname','lastname','companyname','address1','address2','city','state','postcode','country','fullphonenumber','ns1','ns2','ns3','ns4','ns5','email','domain','regperiod','transfersecret'];
    foreach ($fields as $field) {
        $params_to_send[$field] = $params[$field] ?? '';
    }
    $params_to_send['eppcode'] = $params_to_send['transfersecret'];
    $params_to_send['phonenumber'] = $params_to_send['fullphonenumber'];
    $params_to_send['action'] = 'transfer';
    $result = Request::call($params_to_send);
    return ($result['result'] == 'success')
        ? ["success" => "complete"]
        : ["error" => $result['data'] ?? $result['message'] ?? 'Unknown API error'];
}

function wbeen_RenewDomain($params)
{
    $params_to_send = [
        'regperiod' => $params['regperiod'],
        'domain' => $params['domain'],
        'action' => 'renew',
    ];
    $result = Request::call($params_to_send);
    return ($result['result'] == 'success')
        ? ["success" => "complete"]
        : ["error" => $result['data'] ?? $result['message'] ?? 'Unknown API error'];
}

// --------- NAMESERVERS ----------

function wbeen_GetNameservers($params)
{
    $params_to_send = [
        'domain' => $params['domain'],
        'action' => 'getNameServers',
    ];
    $result = Request::call($params_to_send);
    return ($result['result'] == 'success')
        ? $result['data']
        : ['error' => $result['data'] ?? $result['message'] ?? 'Could not fetch nameservers'];
}

function wbeen_SaveNameservers($params)
{
    $postfields = [
        'action' => 'updateNameServers',
        'domain' => $params['domain'],
    ];
    foreach (['ns1','ns2','ns3','ns4','ns5'] as $ns) {
        if (!empty($params[$ns])) {
            $postfields[$ns] = $params[$ns];
        }
    }
    $response = Request::call($postfields);
    return ($response['result'] == 'success')
        ? ['success' => true]
        : ['error' => $response['data'] ?? $response['message'] ?? 'Failed to update nameservers'];
}

// --------- LOCK / UNLOCK ----------
function wbeen_SaveRegistrarLock($params)
{
    $postfields = [
        'action' => 'updateLock',
        'domain' => $params['domain'],
        'lock'   => ($params['lockenabled'] == "locked" ? 1 : 0),
    ];
    $lock_status = Request::call($postfields);

    if ($lock_status['result'] == 'success') {
        return []; // Absolutely nothing else!
    } else {
        return [];
    }
}

function wbeen_GetRegistrarLock($params)
{
    $postfields = [
        'action' => 'lockStatus',
        'domain' => $params['domain'],
    ];
    $lock_status = Request::call($postfields);

    if ($lock_status['result'] == 'success') {
        $status = strtolower(trim($lock_status['data']));
        if ($status == 'locked' || $status === '1' || $status === 1 || $status === true) {
            return "locked";
        }
        if ($status == 'unlocked' || $status === '0' || $status === 0 || $status === false) {
            return "unlocked";
        }
    }
    return "";
}



// --------- PRIVACY PROTECTION / ID PROTECT ----------

function wbeen_IDProtectToggle($params)
{
    $postfields = [
        'action' => 'updatePrivacy',
        'domain' => $params['domain'],
        'protectenable' => ($params['protectenable'] ? 1 : 0),
    ];
    $result = Request::call($postfields);
    return ($result['result'] == 'success')
        ? ['success' => true]
        : ['error' => $result['data'] ?? $result['message'] ?? 'Failed to update privacy'];
}

// --------- EPP CODE ----------

function wbeen_GetEPPCode($params)
{
    $postfields = [
        'domain' => $params['domain'],
        'action' => 'getEPP',
    ];
    $epp_status = Request::call($postfields);
    return ($epp_status['result'] == 'success')
        ? ['eppcode' => $epp_status['data']]
        : ['error' => $epp_status['data'] ?? $epp_status['message'] ?? 'Failed to get EPP'];
}

// --------- CONTACT DETAILS ----------

function wbeen_GetContactDetails($params)
{
    $postfields = [
        'domain' => $params['domain'],
        'action' => 'getContactDetails',
    ];
    $contact_status = Request::call($postfields);
    if ($contact_status['result'] == 'success') {
        unset($contact_status['data']['result']);
        return $contact_status['data'];
    } else {
        return ['error' => $contact_status['data'] ?? $contact_status['message'] ?? 'Failed to get contact details'];
    }
}

function wbeen_SaveContactDetails($params)
{
    $postfields = [
        'domain' => $params['domain'],
        'contactdetails' => json_encode($params['contactdetails']),
        'action' => 'saveContactDetails',
    ];
    $save_status = Request::call($postfields);
    if ($save_status['result'] != 'success') {
        return ['error' => $save_status['data'] ?? $save_status['message'] ?? 'Failed to save contact details'];
    }
    return ['success' => true];
}

// --------- TLD PRICING ----------

function wbeen_GetTldPricing(array $params)
{
    $params_to_send = [];
    $params_to_send['action'] = 'GetTldPricing';
    $result = Request::call($params_to_send);
    if ($result['result'] == 'success') {
        
        $results = new ResultsList;
        $currency = $result["data"]["currency"]["code"];
        foreach ($result["data"]["pricing"] as $extension => $value) {
            // All the set methods can be chained and utilised together.
            $item = (new ImportItem)
                ->setExtension($extension)
                ->setMinYears(1)
                ->setMaxYears(1)
                ->setRegisterPrice($value["register"][1])
                ->setRenewPrice($value["renew"][1])
                ->setTransferPrice($value["transfer"][1])
                ->setCurrency($currency)
                ->setEppRequired($value['transferSecretRequired']);
    
            $results[] = $item;
        }
        return $results;
        // return array("error" => json_encode($result["data"]["pricing"]["in"]));
    } else {
         return array("error" => $result["data"]["pricing"]);
    } 
}
