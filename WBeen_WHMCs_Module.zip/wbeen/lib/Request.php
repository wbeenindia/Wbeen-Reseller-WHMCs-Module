<?php

namespace WHMCS\Module\Registrar\Wbeen;

use WHMCS\Database\Capsule;

class Request
{
    public static function call($post_fields)
    {
        // Defensive: Ensure post_fields is always an array
        if (!is_array($post_fields)) {
            $post_fields = [];
        }

        $api_key = decrypt(Capsule::table('tblregistrars')
            ->where('registrar', '=', 'wbeen')
            ->where('setting', '=', 'apikey')
            ->value('value'));
        $email = decrypt(Capsule::table('tblregistrars')
            ->where('registrar', '=', 'wbeen')
            ->where('setting', '=', 'email')
            ->value('value'));
        $server_url = 'https://secure.wbeen.com/auth.php?apikey=' . urlencode($api_key) . '&email=' . urlencode($email);

        $return = [];
        $response = '';
        $curl_error = '';
        $sslVerified = true;
        $tries = 0;
        $maxTries = 2;

        do {
            $tries++;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $server_url);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_fields));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 15);

            if ($sslVerified) {
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
            } else {
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            }

            $response = curl_exec($ch);

            if (curl_errno($ch)) {
                $curl_error = 'cURL error: ' . curl_error($ch);

                // Only fallback on SSL error, otherwise break!
                if ($sslVerified && (
                    stripos($curl_error, 'SSL') !== false
                    || stripos($curl_error, 'certificate') !== false
                    || stripos($curl_error, 'verify') !== false
                )) {
                    $sslVerified = false; // try next time with SSL off
                    curl_close($ch);
                    continue;
                }
            }
            curl_close($ch);
            break;
        } while ($tries < $maxTries);

        $results = json_decode($response, true);
        if (!$results || !isset($results['result'])) {
            $return = [
                'result' => 'error',
                'data' => $curl_error ? $curl_error : 'The API is temporarily unavailable. Please try again later.'
            ];
        } else {
            $return = $results;
        }

        // Debug log (admin only)
        if (function_exists('logModuleCall')) {
            logModuleCall(
                'wbeen',
                isset($post_fields['action']) ? $post_fields['action'] : 'API',
                $post_fields,
                $response,
                $return,
                []
            );
        }

        return $return;
    }
}
